function f=fun1(x)
f=70/cos(x(2));
end